"""
TASK 4 – Write Correct Expressions
"""
import math

def step_count(value, standard):
    """Calculate nearest 0.1 percentage-point steps using round()."""
    return round((value - standard) / 0.1)

def rate_per_litre(fat, snf):
    """Calculate the rate per litre from fat and SNF percentages."""
    fat_steps = step_count(fat, 3.5)
    snf_steps = step_count(snf, 8.5)
    return round(30.00 + fat_steps * 0.40 + snf_steps * 0.30, 2)

if __name__ == "__main__":
    print("(4.2 - 3.5) / 0.1 =", (4.2 - 3.5) / 0.1)
    print("round((4.2 - 3.5) / 0.1) =", round((4.2 - 3.5) / 0.1))
    print("0.1 + 0.2 =", 0.1 + 0.2)
    print("round(2.675, 2) =", round(2.675, 2))
    print("round(-2.5) =", round(-2.5))
    print("int(-2.5) =", int(-2.5))
    print("math.floor(-2.5) =", math.floor(-2.5))
    print("Fat 4.2, SNF 8.5 rate =", rate_per_litre(4.2, 8.5))
    print("Fat 3.1, SNF 8.5 rate =", rate_per_litre(3.1, 8.5))
    print("Valid fat check:", 2.0 <= 4.2 <= 7.0)
