"""
TASK 6 – Organise the Logic into Functions
"""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP_SIZE = Decimal("0.1")
CENT = Decimal("0.01")

def round_money(amount):
    """Round an amount to the nearest paisa."""
    return Decimal(amount).quantize(CENT, rounding=ROUND_HALF_UP)

def rate_per_litre(fat, snf):
    """Return the rate per litre for the supplied fat and SNF values."""
    fat_steps = int(((Decimal(str(fat)) - STANDARD_FAT) / STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    snf_steps = int(((Decimal(str(snf)) - STANDARD_SNF) / STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return round_money(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE)

def payout(litres, fat, snf):
    """Return the rounded payment for one milk entry."""
    return round_money(Decimal(str(litres)) * rate_per_litre(fat, snf))

def ten_day_total(payments):
    """Return the total of a sequence of payment amounts."""
    return round_money(sum((Decimal(str(p)) for p in payments), Decimal("0.00")))

if __name__ == "__main__":
    amount = payout("8.5", "4.2", "8.7")
    print("Rate per litre:", rate_per_litre("4.2", "8.7"))
    print("Payment:", amount)
    print("Ten-day total:", ten_day_total([Decimal("300.00"), amount]))
