"""
TASK 7 – Build a Module
Rate card and reusable calculation functions.
"""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP_SIZE = Decimal("0.1")
CENT = Decimal("0.01")

def money(amount):
    """Round money to two decimal places."""
    return Decimal(str(amount)).quantize(CENT, rounding=ROUND_HALF_UP)

def rate_per_litre(fat, snf):
    """Return the price per litre rounded to two decimal places."""
    fat_steps = int(((Decimal(str(fat)) - STANDARD_FAT) / STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    snf_steps = int(((Decimal(str(snf)) - STANDARD_SNF) / STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return money(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE)

def payout(litres, fat, snf):
    """Return the amount payable rounded to two decimal places."""
    return money(Decimal(str(litres)) * rate_per_litre(fat, snf))

if __name__ == "__main__":
    for litres, fat, snf in [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]:
        print(f"{litres:5} L  fat {fat}  snf {snf}  rate {rate_per_litre(fat, snf):6.2f}  pay {payout(litres, fat, snf):8.2f}")
