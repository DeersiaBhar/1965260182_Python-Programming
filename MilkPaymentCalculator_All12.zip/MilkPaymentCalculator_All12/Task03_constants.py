"""
TASK 3 – Choose Variables and Name the Constants
"""

BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP_SIZE = 0.1

# Python uses UPPER_CASE by convention for constants.
# Python does not technically prevent a constant from being reassigned.
# Variable names should be descriptive and begin with a letter or underscore.

def show_rate_card():
    """Print all named rate constants."""
    print("Base rate:", BASE_RATE)
    print("Fat step value:", FAT_STEP_VALUE)
    print("SNF step value:", SNF_STEP_VALUE)
    print("Standard fat:", STANDARD_FAT)
    print("Standard SNF:", STANDARD_SNF)
    print("Step size:", STEP_SIZE)

if __name__ == "__main__":
    show_rate_card()

    # Dynamic typing demonstration
    value = 10
    print(value, type(value))
    value = "ten"
    print(value, type(value))

    # Multiple assignment and swapping
    a, b = 5, 9
    a, b = b, a
    print("After swapping:", a, b)
