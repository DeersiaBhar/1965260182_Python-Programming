"""
TASK 11 – Recommend and Defend the Final Design
A small runnable demonstration of the recommended design.
"""
from decimal import Decimal
from milkrate import rate_per_litre, payout, money

def main():
    """Demonstrate exact decimal-based calculations."""
    examples = [
        (Decimal("10"), Decimal("3.5"), Decimal("8.5")),
        (Decimal("8.5"), Decimal("4.2"), Decimal("8.7")),
        (Decimal("12"), Decimal("3.1"), Decimal("8.3")),
    ]
    total = Decimal("0.00")
    for litres, fat, snf in examples:
        rate = rate_per_litre(fat, snf)
        amount = payout(litres, fat, snf)
        total += amount
        print(f"{litres} L | fat={fat}% | SNF={snf}% | rate=Rs {rate:.2f} | pay=Rs {amount:.2f}")
    print("Total payment: Rs", money(total))
    print("\\nRecommendation: use Decimal for money, named constants for rates,")
    print("validation functions, automated tests, and one shared module.")
    print("At large scale, process records in batches and retain audit records.")

if __name__ == "__main__":
    main()
