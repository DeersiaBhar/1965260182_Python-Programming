"""
TASK 10 – Compare Expectations with Execution
Measures float and Decimal totals and runtime for multiple batch sizes.
"""
from decimal import Decimal
from time import perf_counter

def float_total(items):
    """Sum amounts using float."""
    total = 0.0
    for item in items:
        total += float(item)
    return total

def decimal_total(items):
    """Sum amounts using Decimal constructed from strings."""
    total = Decimal("0.00")
    for item in items:
        total += Decimal(item)
    return total

def measure(n):
    """Print totals, difference and elapsed times for n payments."""
    payments = ["33.40", "0.10", "27.80", "300.00"] * (n // 4) + ["33.40"] * (n % 4)

    start = perf_counter()
    f_total = float_total(payments)
    float_seconds = perf_counter() - start

    start = perf_counter()
    d_total = decimal_total(payments)
    decimal_seconds = perf_counter() - start

    print(f"Payments: {n:,}")
    print(f"Float total:   {f_total:.10f} (time {float_seconds:.6f} s)")
    print(f"Decimal total: {d_total} (time {decimal_seconds:.6f} s)")
    print(f"Absolute difference: {abs(Decimal(str(f_total)) - d_total)}")
    print()

if __name__ == "__main__":
    for size in (300, 6000, 150000):
        measure(size)
