"""
TASK 5 – Read Input and Convert Types
"""

def read_number(prompt):
    """Read a number, handling invalid input using try/except."""
    while True:
        text = input(prompt).strip()
        try:
            return float(text)
        except ValueError:
            print("Invalid number. Use digits and a decimal point, e.g. 8.5.")

def main():
    """Read and print a quantity and percentages."""
    farmer_id = input("Farmer ID: ").strip()
    litres = read_number("Milk quantity in litres: ")
    fat = read_number("Fat percentage: ")
    snf = read_number("SNF percentage: ")

    if not farmer_id:
        print("Farmer ID cannot be empty.")
    elif litres <= 0:
        print("Quantity must be greater than zero.")
    elif not 2.0 <= fat <= 7.0:
        print("Fat must be between 2.0 and 7.0.")
    elif not 0.0 <= snf <= 20.0:
        print("SNF must be between 0.0 and 20.0.")
    else:
        print(f"{'Farmer ID':<14}: {farmer_id}")
        print(f"{'Litres':<14}: {litres:8.2f}")
        print(f"{'Fat %':<14}: {fat:8.2f}")
        print(f"{'SNF %':<14}: {snf:8.2f}")

if __name__ == "__main__":
    main()
