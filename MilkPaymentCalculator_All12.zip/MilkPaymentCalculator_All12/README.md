# Python Programming Assignment 1 — Milk Payment Calculator

**Student name:** Enter your name  
**Register number:** Enter your register number  
**Python version:** Python 3.10 or later  
**External libraries:** None; standard library only (`decimal`, `time`, `math`)

## Files and run commands

Run these commands from the VS Code terminal in this folder:

```bash
python Task01_problem_analysis.py
python Task02_values_types.py
python Task03_constants.py
python Task04_expressions.py
python Task05_input_conversion.py
python Task06_functions.py
python milkrate.py
python Task07_use_module.py
python Task08_algorithm.py
python Task09_implementation_testing.py
python Task10_expectation_execution.py
python Task11_final_recommendation.py
python Task12_seasonal_design.py
```

If `python` does not work on Windows, try `py`.

## Notes
- Task 1 documents data, constants, rules and assumptions.
- Task 2 explores Python types, division, and `float` versus `Decimal`.
- Task 3 demonstrates constants, dynamic typing and swapping.
- Task 4 demonstrates rate expressions and rounding behaviour.
- Task 5 demonstrates input conversion and validation.
- Task 6 organizes calculations into documented functions.
- Task 7 demonstrates a reusable module and importing it from a second script.
- Task 8 includes pseudocode and a hand trace.
- Task 9 runs assertions and a five-entry total.
- Task 10 measures totals and runtime for 300, 6,000 and 150,000 entries.
- Task 11 demonstrates the recommended Decimal-based design.
- Task 12 tests seasonal rates and the volume bonus.

Before submission, replace the student details, run every file, capture output screenshots, and push commits progressively to the required GitHub repository. The written report also needs the explanations, complexity comparisons, flowchart, test table, and evidence requested in the assignment.
