"""
TASK 9 – Implement and Test the Calculator
"""
from decimal import Decimal
from milkrate import rate_per_litre, payout, money

MIN_FAT = Decimal("2.0")
MAX_FAT = Decimal("7.0")
MIN_SNF = Decimal("0.0")
MAX_SNF = Decimal("20.0")

def validate_entry(litres, fat, snf):
    """Return True if the numeric entry is valid."""
    litres, fat, snf = Decimal(str(litres)), Decimal(str(fat)), Decimal(str(snf))
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and MIN_SNF <= snf <= MAX_SNF

def ten_day_total(entries):
    """Calculate total payment for entries represented as (litres, fat, snf)."""
    return money(sum((payout(l, f, s) for l, f, s in entries), Decimal("0.00")))

def run_tests():
    """Test expected values, boundaries, and invalid entries."""
    assert rate_per_litre("3.5", "8.5") == Decimal("30.00")
    assert payout("10", "3.5", "8.5") == Decimal("300.00")
    assert rate_per_litre("4.2", "8.7") == Decimal("33.40")
    assert payout("8.5", "4.2", "8.7") == Decimal("283.90")
    assert rate_per_litre("3.1", "8.3") == Decimal("27.80")
    assert validate_entry(1, 2.0, 8.5)
    assert validate_entry(1, 7.0, 8.5)
    assert not validate_entry(-1, 3.5, 8.5)
    assert not validate_entry(1, 7.1, 8.5)
    assert not validate_entry(1, 3.5, 20.1)
    five_entries = [
        (10, 3.5, 8.5),
        (8.5, 4.2, 8.7),
        (12, 3.1, 8.3),
        (5, 3.5, 8.5),
        (2, 4.0, 8.5),
    ]
    print("Five-entry total:", ten_day_total(five_entries))
    print("All tests passed.")

if __name__ == "__main__":
    run_tests()
