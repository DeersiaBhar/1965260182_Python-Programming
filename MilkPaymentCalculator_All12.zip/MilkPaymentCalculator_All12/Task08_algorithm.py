"""
TASK 8 – Plan the Algorithm Before Coding
Pseudocode is included in comments; this program hand-traces three entries.
"""

# PSEUDOCODE
# START
#   Set total = 0
#   FOR each farmer entry
#       Read farmer ID, litres, fat, SNF and shift
#       Validate quantity and percentage ranges
#       Calculate fat_steps = round((fat - 3.5) / 0.1)
#       Calculate snf_steps = round((snf - 8.5) / 0.1)
#       rate = 30 + fat_steps * 0.40 + snf_steps * 0.30
#       payment = round(litres * rate, 2)
#       Add payment to total
#       Display payment
#   END FOR
#   Display total
# END

from decimal import Decimal
from milkrate import payout, money

def main():
    """Trace the payment calculation for three sample entries."""
    entries = [
        ("F001", Decimal("10"), Decimal("3.5"), Decimal("8.5")),
        ("F002", Decimal("8.5"), Decimal("4.2"), Decimal("8.7")),
        ("F003", Decimal("12"), Decimal("3.1"), Decimal("8.3")),
    ]
    total = Decimal("0.00")
    for farmer_id, litres, fat, snf in entries:
        amount = payout(litres, fat, snf)
        total += amount
        print(f"{farmer_id}: payment Rs {amount:.2f}; running total Rs {total:.2f}")
    print("Final total:", money(total))

if __name__ == "__main__":
    main()
