"""
TASK 12 – Re-evaluate and Adapt the Design
Seasonal rates, two-decimal analyser readings, and ten-day volume bonus.
"""
from decimal import Decimal, ROUND_HALF_UP

STEP = Decimal("0.1")
STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
CENT = Decimal("0.01")
BONUS_THRESHOLD = Decimal("500")
BONUS_PER_LITRE = Decimal("0.50")

RATE_CARDS = {
    "regular": {
        "base": Decimal("30.00"),
        "fat_step": Decimal("0.40"),
        "snf_step": Decimal("0.30"),
    },
    "april_june": {
        "base": Decimal("32.00"),
        "fat_step": Decimal("0.45"),
        "snf_step": Decimal("0.30"),
    },
}

def money(amount):
    """Round money to two decimal places."""
    return Decimal(str(amount)).quantize(CENT, rounding=ROUND_HALF_UP)

def count_steps(value, standard):
    """Convert a reading into the nearest 0.1 percentage-point step."""
    return int(((Decimal(str(value)) - standard) / STEP).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

def rate_per_litre(fat, snf, season="regular"):
    """Return the rate using the chosen seasonal rate card."""
    if season not in RATE_CARDS:
        raise ValueError("Unknown season.")
    card = RATE_CARDS[season]
    fat_steps = count_steps(fat, STANDARD_FAT)
    snf_steps = count_steps(snf, STANDARD_SNF)
    return money(card["base"] + fat_steps * card["fat_step"] + snf_steps * card["snf_step"])

def payout(litres, fat, snf, season="regular", ten_day_litres=Decimal("0")):
    """Return payment including bonus if ten-day quantity exceeds 500 litres."""
    litres = Decimal(str(litres))
    ten_day_litres = Decimal(str(ten_day_litres))
    amount = litres * rate_per_litre(fat, snf, season)
    if ten_day_litres > BONUS_THRESHOLD:
        amount += litres * BONUS_PER_LITRE
    return money(amount)

def run_tests():
    """Test both seasons and the bonus boundary."""
    assert rate_per_litre("3.50", "8.50", "regular") == Decimal("30.00")
    assert rate_per_litre("3.50", "8.50", "april_june") == Decimal("32.00")
    assert payout(10, "3.50", "8.50", "april_june", 500) == Decimal("320.00")
    assert payout(10, "3.50", "8.50", "april_june", 501) == Decimal("325.00")
    print("All Task 12 tests passed.")

if __name__ == "__main__":
    run_tests()
    for season in ("regular", "april_june"):
        rate = rate_per_litre("4.25", "8.55", season)
        print(season, "rate:", rate)
    print("Payment with bonus:", payout(10, "3.50", "8.50", "april_june", 501))
