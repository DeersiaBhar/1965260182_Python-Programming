"""Second script demonstrating import of milkrate.py."""
import milkrate as mr

def main():
    """Call functions from the imported module."""
    litres, fat, snf = 8.5, 4.2, 8.7
    rate = mr.rate_per_litre(fat, snf)
    amount = mr.payout(litres, fat, snf)
    print(f"Rate per litre: Rs {rate:.2f}")
    print(f"Payment: Rs {amount:.2f}")

if __name__ == "__main__":
    main()
