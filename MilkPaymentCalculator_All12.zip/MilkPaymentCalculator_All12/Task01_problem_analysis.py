"""
TASK 1 – Understand the Problem and Identify the Data
This file records the inputs, outputs, constants, types, and validation rules.
"""

# Inputs for each entry:
# farmer_id: str (identifies the farmer)
# litres: Decimal (fractional quantity of milk)
# fat: Decimal (fat percentage)
# snf: Decimal (solids-not-fat percentage)
# shift: str ("morning" or "evening")

# Outputs:
# rate_per_litre: Decimal (price for one litre)
# payment: Decimal (amount for this entry)
# ten_day_total: Decimal (sum of a farmer's payments over ten days)

# Named constants:
BASE_RATE = 30.00
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STANDARD_FAT = 3.5
STANDARD_SNF = 8.5
STEP_SIZE = 0.1
MIN_FAT = 2.0
MAX_FAT = 7.0

# Assumptions:
# 1. Quantity must be greater than zero.
# 2. Fat must be between 2.0% and 7.0%, inclusive.
# 3. SNF range is assumed to be 0.0%–20.0% because the brief gives no SNF limits.
# 4. Each payment is rounded to two decimal places.
# 5. Each fat/SNF step is rounded to the nearest 0.1 percentage point.

def validate_entry(litres, fat, snf):
    """Return True when an entry meets the validation rules."""
    return litres > 0 and MIN_FAT <= fat <= MAX_FAT and 0.0 <= snf <= 20.0

if __name__ == "__main__":
    print("Task 1: inputs, outputs, constants and assumptions are documented.")
    print("Valid example:", validate_entry(10.0, 3.5, 8.5))
    print("Invalid example:", validate_entry(-2.0, 3.5, 8.5))
