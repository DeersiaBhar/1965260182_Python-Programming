"""
TASK 2 – Explore Values and Types in the Interpreter
"""
from decimal import Decimal

values = [10, 10.0, "10", True, [10, 8.5]]
for value in values:
    print(repr(value), "->", type(value))

print("7 / 2 =", 7 / 2)
print("7 // 2 =", 7 // 2)
print("7 % 2 =", 7 % 2)
print("-7 // 2 =", -7 // 2)

print("0.1 + 0.2 == 0.3:", 0.1 + 0.2 == 0.3)
print('Decimal("0.1") + Decimal("0.2") == Decimal("0.3"):',
      Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))

payments = ["33.40"] * 1000 + ["0.10"] * 3

def total_float(items):
    """Add string amounts as floats."""
    total = 0.0
    for item in items:
        total += float(item)
    return total

def total_decimal(items):
    """Add string amounts using Decimal to avoid binary float errors."""
    total = Decimal("0.00")
    for item in items:
        total += Decimal(item)
    return total

print("float  :", total_float(payments))
print("Decimal:", total_decimal(payments))
print("Decimal(float('0.1')):", Decimal(float("0.1")))
